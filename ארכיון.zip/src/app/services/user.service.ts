import { Injectable } from '@angular/core';
import { User } from '../models/user.model';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor() { }
 public getUser(){
  const user:User= {
      name: "Ochoa Hyde",
      coins: 100,
      moves: []
    }
  return user
  }
}
