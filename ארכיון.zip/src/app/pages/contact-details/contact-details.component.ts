import { Component, Input, OnInit } from '@angular/core';
import { Contact } from '../../models/contact.model';
import { ContactService } from '../../services/contact.service';

@Component({
  selector: 'contact-details',
  templateUrl: './contact-details.component.html',
  styleUrls: ['./contact-details.component.scss']
})
export class ContactDetailsComponent implements OnInit {
  // @Input() contactId
  constructor(private contactService:ContactService) { }
  contact={
    name:'guy'
  }
  ngOnInit(): void {
    // this.loadContact()
  }
  // ngOnChanges(change):void{
  //   if(change.contactId && !change.contactId.firstChange){
  //     this.loadContact()
  //   }
  // }
  // loadContact(){
  //   if(this.contactId){
  //     const contact$ = this.contactService.getContactById(this.contactId)
  //     contact$.subscribe(contact=>this.contact=contact)
  //   }else this.contact = null
  // }

}
