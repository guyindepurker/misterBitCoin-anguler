import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { ContactService } from '../../services/contact.service';
import { Contact } from '../../models/contact.model';

@Component({
  selector: 'contact-page',
  templateUrl: './contact-page.component.html',
  styleUrls: ['./contact-page.component.scss']
})
export class ContactPageComponent implements OnInit {
  subscription: Subscription
  contacts:Contact[] = []
  contactId:string = null
  constructor(private contactService:ContactService) { }

  ngOnInit(): void {
    this.subscription = this.contactService.contacts$.subscribe(contacts=>{
      console.log(contacts);
      this.contacts = [...contacts]
      console.log(' this.contacts :',  this.contacts )
    })

  }
  ngOnDestroy() {
    this.subscription.unsubscribe()
  }
  setContactId(contactId) {
    this.contactId = contactId;
  }
  
}
