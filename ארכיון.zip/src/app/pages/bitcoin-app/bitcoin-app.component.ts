import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'bitcoin-app',
  templateUrl: './bitcoin-app.component.html',
  styleUrls: ['./bitcoin-app.component.scss']
})
export class BitcoinAppComponent implements OnInit {
  
  constructor() { }

  ngOnInit(): void {
  }

}
