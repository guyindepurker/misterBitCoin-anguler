import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'chart',
  templateUrl: './chart.component.html',
  styleUrls: ['./chart.component.scss']
})
export class ChartComponent implements OnInit {
  // @Input() data 
  // @Input() type
  constructor() { }
  myData = [
    ['London', 8136000],
    ['New York', 8538000],
    ['Paris', 2244000],
    ['Berlin', 3470000],
    ['Kairo', 19500000]]
    chartColumns = ['City', 'Inhabitants','Paris','Berlin','Kairo'];
  ngOnInit(): void {
  }

}
