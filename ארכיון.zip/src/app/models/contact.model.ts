import { UtilService } from "../services/util.service";

export class Contact {

    constructor(private utilService: UtilService,public _id?: string, public name: string = '', public email: string = '', public phone: string = '' ) {
       
    }
    
   public setId?() {
        // Implement your own set Id
        this._id = this.utilService.makeId()
    }
    // private makeId(length = 5) {
    //     var text = "";
    //     var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    //     for (var i = 0; i < length; i++) {
    //       text += possible.charAt(Math.floor(Math.random() * possible.length));
    //     }
    //     return text;
    //   }
}