import { UtilService } from "../services/util.service";

export class Move {

    constructor(private utilService: UtilService,public _id?: string, public todId: string ='', public to: string = '', public at: number = null,public amount:number=null ) {

    }

    setId?() {
        // Implement your own set Id
        this._id = this.utilService.makeId()
    }
}